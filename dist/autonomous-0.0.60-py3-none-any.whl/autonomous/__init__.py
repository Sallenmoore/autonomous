__version__ = "0.0.60"

from .logger import log
